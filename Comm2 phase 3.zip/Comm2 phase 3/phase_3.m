clc;
clear;

%loading text 
data = importdata('bonus.txt');
textContent = data{1,1};

%convert text to ASCII 
asciiValues = double(textContent);
totalChars = length(asciiValues);

% Initialize array to track ASCII value frequencies
asciiFrequency = zeros(1, 128);

% Calculate frequency of each ASCII character
for asciiIndex = 0:127
    occurrence = 0;
    for charIndex = 1:totalChars
        if (asciiValues(charIndex) == asciiIndex)
            occurrence = occurrence + 1;
        end
    end
    asciiFrequency(asciiIndex+1) = occurrence;
end

% Identify characters and their frequencies
activeChars = find(asciiFrequency) - 1;
frequencies = asciiFrequency(activeChars + 1);

% Compute probability of occurrence for each character
charProbabilities = frequencies / totalChars;

% Ensure probabilities sum to 1
charProbabilities = charProbabilities / sum(charProbabilities);

% Compute entropy of the text
entropyValue = -sum(charProbabilities .* log2(charProbabilities));

%display the statistics
fprintf('Character Analysis:\n');
fprintf('%-12s %-12s %-12s\n', 'Character', 'Frequency', 'Probability');

for index = 1:length(activeChars)
    fprintf('%-12c %-12d %-12.4f\n', char(activeChars(index)), frequencies(index), charProbabilities(index));
end

fprintf('Entropy: %.4f bits/symbol\n', entropyValue);

% Implement Huffman coding
[huffmanDict, avgLength] = huffmandict(activeChars, charProbabilities);
encodedText = huffmanenco(textContent, huffmanDict);

% Display Huffman coding results
fprintf('\nHuffman Coding:\n');
fprintf('%-12s %-12s %-20s\n', 'Probability', 'Character', 'Codeword');

for index = 1:length(activeChars)
   fprintf('%-12.4f %-12c %-20s\n', charProbabilities(index), char(activeChars(index)), num2str(cell2mat(huffmanDict(index,2))));
end

% Encode and decode text to verify
decodedText = huffmandeco(encodedText, huffmanDict);

% Display Huffman encoding efficiency
originalLength = 8 * length(textContent);
encodedLength = length(encodedText);
efficiency = (entropyValue / avgLength) * 100;
compressionRatio = (encodedLength / originalLength) * 100;

fprintf('Original Length: %d bits\n', originalLength);
fprintf('Encoded Length: %d bits\n', encodedLength);
fprintf('Average Length: %.4f bits/symbol\n', avgLength);
fprintf('Efficiency: %.2f%%\n', efficiency);
fprintf('Compression Ratio: %.2f%%\n', compressionRatio);

disp('Decoded Text:');
fprintf('%s\n', decodedText);
