
function [PCM_t, PCM_signal] = Encoder(Fs, bit_stream, pulse_amplitude, line_code, bit_rate, n) %n #samples/bit === the number of samples representing each bit
    Tb = 1/bit_rate;    %bit duration
    Ts = 1/Fs;

    % if (Ts < R*Tb)
    %     warning("Not valid! the sampling period must be larger than the bit frame total duration!");
    % end

    t_total = length(bit_stream) * Tb;  %total time duration of all bits
    n_total = n*length(bit_stream);
    t_step = Tb / n;
    PCM_t = 0 : t_step : t_total-t_step;
    
    PCM_signal = zeros(1, n_total);
    A = pulse_amplitude;    %for simplicity

    if(line_code == 0)  %Manchester Signaling
        for i=1 : length(bit_stream)
            if (bit_stream(i)==1)
                PCM_signal((i-1)*n +1 : (i-1)*n+(n/2)) = A;
                PCM_signal((i-1)*n+(n/2)+1 : i*n) = -A;
            else
                PCM_signal((i-1)*n +1 : (i-1)*n+(n/2)) = -A;
                PCM_signal((i-1)*n+(n/2)+1 : i*n) = A;
            end
        end
        
        figure_title = 'Manchester Signal';
    
    elseif(line_code == 1)  %  AMI Signaling
        for i=1 : length(bit_stream)
            if (bit_stream(i)==1)
                PCM_signal((i-1)*n +1 : i*n) = A;
                A = -A;
            % for 0 bits, the PCM signal is already initialized by zeros
            end
        end
        figure_title = 'AMI Signal';
    end

    nexttile
    plot(PCM_t(1: 20*n),PCM_signal(1 : 20*n));    %Plotting the first 10 bits only
    xlabel('t[sec.]');
    ylabel('Amplitude');
    title(strcat(figure_title, ' first 20 bits'));
    legend('Encoder output');
end





















% function  [out]  = Encoder (quantizer_out,number_of_bits,fs,type,amplitude)
% 
% figure;
% bit_rate= fs * number_of_bits;
% bit_duration = 1 / bit_rate;
% %t=0:bit_duration:bit_duration*length(quantizer_out);
% 
% if type == 2 % ALTERNATE MARK INVERSION
%     bit_0 = zeros(1, length(bit_duration));
%     bit_1 = 1 * (bit_duration <= 0.5 * bit_duration);
%     bit_1_isEven = true;
%     out = 0;
% 
%     for i = 1:length(quantizer_out)
%         if (quantizer_out(i))
%             if (bit_1_isEven)
%                 out = [out bit_1];
%                 bit_1_isEven = false;
%             else
%                 out = [out -bit_1];
%                 bit_1_isEven = true;
%             end
%         else
%             out = [out bit_0];
%         end
%          t_AltMarkInv = 0:bit_duration:(bit_duration * (length(quantizer_out) - 1));
%     out = out(2:length(out));
%     out = out(1:length(t_AltMarkInv));
% 
%     stairs(t_AltMarkInv, out, 'g');
%     title("Alternate Mark Inversion Encoding");
%     xlim([0 0.01 * bit_duration * length(out)]);
%     ylim([-3 * amplitude 2 * amplitude]);
%     grid on;
% 
%     end
% 
% 
% 
% elseif type == 1 % to do manchester signal encoding
%     j=1;
%     Manchester= zeros(1,21);
%     for i=1:length(quantizer_out)
%         Manchester([j j+1]) = [quantizer_out(i) ~quantizer_out(i)];
%         j=j+2;
%     end
%     Manchester(Manchester==0)=-1;
%     out=5*Manchester;
%     out=[out 0];
%     %t_manchester=0:bit_duration/2:(bit_duration/2)*length(Manchester);
%     t_manchester = 0:bit_duration/2:(bit_duration/2)*(length(Manchester));
%     stairs(t_manchester,out,'g');
%     title("Manchester signaling Encoding");
%     xlim([0 0.01*bit_duration*length(out)]);
%     ylim([-3*amplitude 2*amplitude]);
% grid on;
% end
% end