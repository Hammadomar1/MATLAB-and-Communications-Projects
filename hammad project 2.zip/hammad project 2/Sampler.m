% 
function [Sampled_Signal, Sampled_Time] = Sampler(Time_step, T_end, Input_Function, Fs, t)
    Ts = 1 / Fs;
    Multiples = round(Ts / Time_step);  % Round to the nearest integer

    Sampled_Signal = Input_Function(1 : Multiples : end);
    Sampled_Time = 0 : Ts : Ts * (length(Sampled_Signal) - 1);

    for i = 1 : length(Sampled_Signal)
        if abs(Sampled_Signal(i)) < 0.000001
            Sampled_Signal(i) = 0;
        end
    end

    stem(Sampled_Time, Sampled_Signal);
    title("samples of the input audio file");
    hold on;
    
    % Ensure t has the same length as Sampled_Time
    t = t(1:length(Sampled_Time));
    
    plot(t, Input_Function(1:length(Sampled_Time)),'y');
    title("samples of the input audio file");
    grid on;
end






% function [Sampled_Signal,Sampled_Time]= Sampler(Time_step,T_end,Input_Function,Fs,t)
% 
% 
% %After assuming signal is continous in the array of the input we need to
% %know the indexes of samples that I would take there need to know ratio
% %between Ts,UnitStep
% Ts = 1 / Fs;
% Multiples=(Ts / Time_step);
% Sampled_Signal=Input_Function(1:Multiples:end);
% for i=1:length(Sampled_Signal) %to solve floating point problem at zero
%     if (Sampled_Signal(i)<0.000001  && Sampled_Signal(i)>-0.000001)
%         Sampled_Signal(i)=0;
%     end
% end
% 
% Sampled_Time=0:Ts:T_end;
% stem (Sampled_Time,Sampled_Signal);
% hold on 
% plot(t,Input_Function,'r');
% grid on
% end