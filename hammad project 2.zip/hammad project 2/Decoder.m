
function [decoded_signal] = Decoder(encoded_signal, num_levels, peak_quantization_level)
    % Decode the bitstream
    decoded_bits = encoded_signal > 0;

    % Convert bits back to quantized samples
    decoded_decimal = sum(decoded_bits .* 2.^(numel(decoded_bits)-1:-1:0));

    % Normalize the decoded decimal value
    decoded_signal = (decoded_decimal - 0.5) * (2 * peak_quantization_level / (2^num_levels - 1));

    % Display the decoded quantized samples
    figure;
    stem(decoded_signal);
    xlabel('Sample Index');
    ylabel('Amplitude');
    title('Decoded Quantized Samples');
end








%%%%% THE FIZO CODE %%%%%%

% function [Decoded_Signal] = Decoder(bitStream, nBits, mp, type)
% %DEQUANTIZE Summary of this function goes here
% %   Detailed explanation goes here
%     L = 2^nBits;
% 
%     quantizer_step = 2*mp/L;
%     levels_analog = -mp:quantizer_step:mp-quantizer_step;
%     % levels_binary = 0:L-1;
% 
%     if(type == "mid-rise")
%         levels_analog = levels_analog + quantizer_step/2;
%     end
%     m_dequantized = zeros(1, ceil(length(bitStream)/nBits));
%     j = 1;
%     for i=1:nBits:length(bitStream)
%         sample_binary = int2str(bitStream(i:(i+nBits-1)));
%         m_dequantized(j) = levels_analog((bin2dec(sample_binary)+1));
%         j = j+1;
%     end
% end





% function [MyOut]=Decoder(InputSignal,AmplitudeOfQuantizer,LevelsOfQuantizer,Voltage,TypeCoding,Sampled_Time)
% 
% Out = InputSignal;
% levels = LevelsOfQuantizer; %number of levels of quantizer
% Amplitude = AmplitudeOfQuantizer; %max amplitude of quantizer
% mp = AmplitudeOfQuantizer;
% Delta = (2 * Amplitude) / levels; 
% NumberOfBits=log2(levels);
% Volt=Voltage; %Max voltage of signal 
% Out=Out./Volt;
% Increment=(length(Out))/NumberOfBits;
% Type=TypeCoding; %Manshester coding
% %TypeQ='Non-Uniform'; Nonunifrom quantizer
% %uniPolar
% inc=1;
% MyOut=zeros(0,1);
% figure;
% %Convert Polar to UniPolar
% if (strcmp(Type,'polar'))
%    for i=1:1:length(Out)
%        if(Out(i)==-1)
%            Out(i)=0;
%        end
%    end
% end
% %///////////////////////////////////
% %Convert Manchester to Polar
% Tempc=1;
% Temp=zeros(0,1);
% if TypeCoding == 1
%    for i=1:2:(length(Out))
%        if(Out(i)==1 && Out(i+1)==-1)
%            Temp(Tempc)=1;
%            Tempc=Tempc+1;
%        elseif(Out(i)==-1 && Out(i+1)==1)
%            Temp(Tempc)=0;
%            Tempc=Tempc+1;
%        end
%    end
%     Out=Temp;
% end
% 
% 
% 
% %///////////////////////////////////////////
% %Return Polar signal
% for i=1:NumberOfBits:length(Out)
%     Period=round( Out(i:times(inc,NumberOfBits)) );
%     Period = abs(Period);
%     PERIOD = double(dec2bin(Period));
%     PeriodAmp=bit2int(PERIOD,2,'left-msb');
%     Amp=(PeriodAmp*Delta)-((2^(NumberOfBits-1)-1)*Delta)-(Delta/2);
%     MyOut(inc)=Amp;
%     inc=inc+1;
%    bit2int()
% end
% %Sampled_Time = Sampled_Time(1:length(MyOut));
% 
% stem(Sampled_Time(1:length(MyOut),MyOut));
% end
