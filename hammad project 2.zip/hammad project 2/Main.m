clear;

[Input_Function,Fm]=audioread('Dr.Samy.wav');

T_end = length(Input_Function) / Fm;

Fs = input('Please Enter Sampling Frequncy(Fs) in KHz =');
Time_step= 1 / (10000 * Fs);%ASSUME TO MAKE IT AS A CONTINOUS SIGNAL TIME_STEP IS VERY SMALL AND FUNCTION OF FS TO MAKE IT HAVE MULTIPLES OF IT
t = 0 : Time_step : T_end; % Time vector 
%Input_Function=input('Please Enter Input signal m(t) ='); % place audio read function

% Quantizer_Type=input('Please Enter Quantizer_Type='); %%
Number_of_Levels = input('Please Enter Number Of Levels='); %%
Peak_Value = max(Input_Function); %% Peak value of quantizer
type = input('Please Specify quantizer type : \n 1 for mid-rise \n 2 for mid-tread'); %%
mp = Peak_Value; % peak quantization level = max of the input function 
Encoding_Type = input('Please Enter The Encoding Type: \n 1 for manchester \n 2 for AMI'); %%
Amplitde_Encoder = input('Please Enter Encoding Amplitude ='); %%
bitstream = 20; % 20 bits
 [Sampled_Signal,Sampled_Time] = Sampler(Time_step,T_end,Input_Function,Fs,t);
 
[mean_square_error, quantized_signal] = quantizer(t, Input_Function, type, Number_of_Levels, mp);

 %%[quantized_signal,MSE,bit] =  quantizer(t,Input_Function,Number_of_Levels,mp,type);
 %%%%%%% quantizer(Sampled_Signal,Sampled_Time,Number_of_Levels,Peak_Value,type);%%%%%%%%%%%%
n=100;
line_code=1;
bit_rate= Fs * 6;
[PCM_t, PCM_signal] = Encoder(Fs, bitstream, Amplitde_Encoder, line_code, bit_rate, n);
% [Encoded_Signal] = Encoder (quantized_signal,bitstream,Fs,Encoding_Type,Amplitde_Encoder);
 
 [decoded_signal] = Decoder(Encoded_Signal,Number_of_Levels, mp);

 %[Decoded_Signal] = Decoder(Encoded_Signal,Peak_Value,Number_of_Levels,Amplitde_Encoder,Encoding_Type,Sampled_Time);
 
 [receivedSignal] = ReconFilter(decoded_signal, Fs);
 
 plot(t,Input_Function,'r');
 
 
 
%%Fourier Transform Representation 
figure;
subplot(3,1,1);
l = length(fft(Input_Function));
f = -l/2:1:(l/2)-1;
plot(f,fft(Input_Function));
subplot(3,1,2);
sampled=Sampled_Signal;
%sampled(isnan(sampled)) = 0;
l = length(fft(sampled));
f = -l/2:1:(l/2)-1;
plot(f,fft(sampled));
subplot(3,1,3);

l = length(fft(receivedSignal));
f = -l/2:1:(l/2)-1;
plot(f,fft(receivedSignal));

sound(receivedSignal,Fs);