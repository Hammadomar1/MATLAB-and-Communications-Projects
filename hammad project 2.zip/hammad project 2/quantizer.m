function [mean_square_error, quantized_signal] = quantizer(time_vector, input_signal, quantizer_type, num_levels, mp)
    % Quantize the input signal
    if quantizer_type == 1 %mid-rise
        quantized_signal = round(input_signal / mp * (num_levels - 1)) * mp / (num_levels - 1);
    elseif quantizer_type == 2 % mid-tread
        quantized_signal = round((input_signal + mp / 2) / mp * (num_levels - 1)) * mp / (num_levels - 1);
    else
        error('Invalid quantizer type');
    end

    % Calculate mean square quantization error
    mean_square_error = mean((input_signal - quantized_signal).^2);

    % Display the input and quantized signals
    figure;
    %plot(time_vector(1:size(input_signal)), input_signal, 'DisplayName', 'Input Signal');
    %hold on;
    stem(time_vector(1:size(input_signal)), quantized_signal, 'DisplayName', 'Quantized Signal', 'Marker', 'o');
    %stairs(time_vector(1:size(input_signal)), quantized_signal, 'DisplayName', 'Quantized Signal');
    legend;
    xlabel('Time (s)');
    ylabel('Amplitude');
    title('Quantizer output');

    
    % Convert quantized signal to bitstream
     %bitstream = dec2bin( quantized_signal + mp, floor(log2(2*mp+1)) );
end







%%%%%%% CODE 2 - EZZ

% function [quantized_signal, MSE, bit_stream] = quantizer(signal_time, signal_amplitude, L, mp, type)
% % Quantizer function with options for type and peak quantization level
% 
% % Calculate quantization step size
% 
% step_size = 2 * mp/(L-1);
% 
% % Quantization levels
% 
% levels = - mp : step_size : mp;
% 
% % Quantize signal
% 
% quantized_signal = zeros(size(signal_amplitude));
% 
% for i = 1:length(signal_amplitude)
% 
%     if type == 1
%         quantized_signal(i) = levels(find(levels >= signal_amplitude(i), 1));
%     elseif type == 2
%         quantized_signal(i) = levels(find(levels > signal_amplitude(i), 1) - 1);
%     end
% end
% 
% % Calculate mean square quantization error
% MSE = mean((signal_amplitude - quantized_signal).^2);
% 
% % Convert quantized signal to bit stream
% bit_stream = dec2bin( quantized_signal + mp, floor(log2(2*mp+1)) );
% 
% % Plot input and quantized signals
% figure;
% 
% %plot(signal_time, signal_amplitude, 'b'); 
% %hold on;
% stairs(signal_time, quantized_signal, 'r');
% legend('Input Signal', 'Quantized Signal');
% xlabel('Time');
% ylabel('Amplitude');
% title(sprintf('%s Quantization with L = %d and Mp = %d', type, L, mp));
% 
% end

%%%%%%%%%%%%%%%%% CODE CAIRO UNI

% function [quantized_signal,bit]=quantizer(sampled_signal,time,L,mp,type)
% 
% quantizer_input = sampled_signal;
% 
% m_max=mp;
% bit=log2(L); %number of bits
% signal=quantizer_input; %get the signal
% %m_max=max(abs(signal)); %find the highest magnitude used
% delta=(2*m_max)/L ;  %our step size
% k_max=(2^bit)/2; %how many levels we have in one side of the quatization graph
% new_signal=zeros(1,length(signal));
% for i=1:length(signal)
%     for k=0:1:(k_max-1)
%         if (((k*delta)<=abs(signal(i)))&&(abs(signal(i))<=((k+1)*delta)))
%             if(signal(i)>0)
%                 new_signal(i)=(0.5+k)*delta;
%             elseif(signal(i)<0)
%                 new_signal(i)=(-0.5-k)*delta;
%             else %signal(i)==0  
%                 if i==1   %assume first zero of signal will be quantized +ve value
%                     new_signal(i)=(0.5+k)*delta;
%                 elseif(signal(i-1)>=0) %qunatizing zero to +value as it comes from postive
%                     new_signal(i)=(0.5+k)*delta;
%                 else %signal(i-1)<0   qunatizing zero to -value as it comes from negative
%                     new_signal(i)=(-0.5-k)*delta;
%                 end
% 
% 
%             end 
%         end
% 
%     end
% end
% figure;
% stem(time,sampled_signal,'r');
% title("Quantizer output");
% hold on
% stem(time,new_signal);
% grid on
% fixed_signal=(new_signal+(delta/2)+((k_max-1)*delta))/delta;
% fixed_signal=abs(fixed_signal);
% quantized_signal= de2bi(((new_signal+(delta/2)+((k_max-1)*delta))/delta),bit,2,'left-msb');
% quantized_signal=quantized_signal';
% quantized_signal=quantized_signal(1:end);
% end 