

function [ReconstedSignal] = ReconFilter(DecodedMessage,Fs)

% Reconstruction Filter is a Sinc Funtion in Time Domain as it is a Rect in Frequency Domain
% To Choose The Low Frequency Component.
DecodedMessage = rot90(DecodedMessage);
Time = 0: 1 / 10000 * Fs : 1;
index = 1; 
for StepTime = 0:1/10000*Fs:1 % Time Domain Convolution with Sinc Filter.
    ReconstedSignal(index) = 0;
    for T = 0:size(DecodedMessage) - 1 % Integration (Summation). -> DecodedMessage(T)* sinc(Fs*t-T) dT
        ConvPart = DecodedMessage(T+1)* sinc(Fs*StepTime-(T));
        ReconstedSignal(index) = ReconstedSignal(index) + ConvPart;
    end
    index=index+1;
end
%Drawing.
figure;
plot(Time,ReconstedSignal,'color','b')
hold on
legend('Reconstructed Signal');
grid;
xlabel('Time(s)');
ylabel('Amplitude');

end