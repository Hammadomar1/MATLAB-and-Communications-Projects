function [PAM_signal] = PAM(c, x)
    %c = 0.5.*(square(2 * pi * t1 / T)+1);  % square wave carrier signal
    %c(c<0)=0;                    % to make it unipolar

    % PAM signal by multiplying the message signal with the carrier
   PAM_signal = x .* c;
  
    
  %%%% plotting %%%
    % Plot the Message signal
    % subplot(3,1,1);
    % plot(t, x);
    % title('Message');
    % xlabel('Time (s)');
    % ylabel('Amplitude');
    % % Plot the Carrier signal
    % subplot(3,1,2);
    % plot(t, c);
    % ylim([-0.2 1.2]);
    % title('carrier');
    % xlabel('Time (s)');
    % ylabel('Amplitude');
    % % Plot the PAM signal
    % subplot(3,1,3);
    % plot(t, PAM_signal);
    % title('PAM Signal');
    % xlabel('Time (s)');
    % ylabel('Amplitude');
end