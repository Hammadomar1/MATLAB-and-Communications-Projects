function [flat_top_pam_signal,s]= ft_pam(m, n, dutycycle)
fc=50;
 s = 0.5.*(square(2*pi*fc*n,dutycycle)+1); % square wave carrier signal
 %s(s<0)=0;                    % to make it unipolar


period_sam = length(n)/fc;     %to find the number of samples in one period
ind = ceil(1:period_sam:length(n));   %to find the starting sample index
on_samp = ceil(period_sam * dutycycle/100);   %no. of samples in "ON" period of time
pam = zeros(1,length(n)); 

for i =1:length(ind) % iterates over the starting sample indices 

    %within each period, it sets a portion of the PAM signal "pam" to
    % be equal to the corresponding sample of the message signal m

    pam(ind(i):ind(i)+on_samp) = m(ind(i)); 
% (starting sample index: ending sample index of ON period) = retrieves the corresponding sample from the message signal
end
 flat_top_pam_signal= pam;

end

