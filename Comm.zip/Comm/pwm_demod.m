function demodulated_pwm = pwm_demod(t2,pwm_signal)
width_pwm = zeros(1,length(pwm_signal)); % initialzation
n = t2(1) : 1/10 : t2(end);
k=1;
for i = 1: length(pwm_signal)
    if pwm_signal(i) == 0 && pwm_signal(i-1) == 1 % detects falling edge
           for j =  i - 100 : i % 73 will change according to time vector of the user (first i of width)
                width_pwm(j) = (i/2000) - n(k); % width = falling edge of pwm minus the last Ts
            end
           k = k + 1;
    else
           width_pwm(i) = 0;
    end

end
    filter_length = 500; %varying the sharpness of the LPF (filter Length)  
    LPF = fir1(filter_length, 0.00004);
    demodulated_pwm = 100.*conv(width_pwm,LPF,"same") - 2;
end