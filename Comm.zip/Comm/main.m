
clear;
cutoff_frequency = 370;  % Cutoff frequency for the low-pass filter

                    % Conventional PAM parameters %
Fs = 2000;  % Sampling frequency
T = 0.5;          % Period     
step = 0.01;   %step

t1 = 0:step:10;    % Time vector
x = 5*cos(t1);
Tw= 50;   %pulse width (percentage of the period)
c = 0.5.*(square(2 * pi * t1 / T, Tw)+1); % carrier signal

[PAM_signal] = PAM(c, x);
[demodulated_signal,t] = LP_Filter(PAM_signal, Fs, cutoff_frequency);

% Plot the Message signal
    subplot(4,1,1);
    plot(t1, x);
    ylim([-1.5 1.5]);
    title('Message');
    xlabel('Time (s)');
    ylabel('Amplitude');

    % Plot the Carrier signal
    subplot(4,1,2);
    plot(t1, c);
    ylim([-0.2 1.5]);
    title('carrier');
    xlabel('Time (s)');
    ylabel('Amplitude');

    % Plot the PAM signal
    subplot(4,1,3);
    plot(t1, PAM_signal);
    title('PAM Signal');
    xlabel('Time (s)');
    ylabel('Amplitude');
     ylim([-1.5 1.5]);

    % Plot the Demodulation of PAM signal
    subplot(4,1,4);
    plot(t, demodulated_signal); % to make the amplitude same
    title('Demodulation of PAM');
    xlabel('Time (s)');
    ylabel('Amplitude');
    ylim([-1.5 1.5]);


                    % Flat_Top PAM parameters %
fc = 10;
fm =1;
fs = 2000;
%t=1;
%n = 0:1/Fs:t;
%n = n(1:end-1);
n = (0:(length(t1) - 1)) / fs;
dutycycle = 50;


% Generate the message signals (you can use any message signal you want)
%m = sin(2*pi*fm*n);

% Calling  functions

[ft_pam_signal, s]=ft_pam(x, n, dutycycle);
[demodulated_signal,t] = LP_Filter(ft_pam_signal, Fs, cutoff_frequency);

figure;
% Plot the Message signal
subplot(4,1,1);
plot(n,x);
ylim([-1.2 1.2]);
title('Message');
xlabel('Time (s)');
ylabel('Amplitude');
% Plot the Carrier signal
subplot(4,1,2);
plot(n,s);
ylim([-0.2 1.2]);
title('Carrier');
xlabel('Time (s)');
ylabel('Amplitude');
 % Plot the PAM signal
subplot(4,1,3);
plot(n,ft_pam_signal);
ylim([-1.5 1.5]);
title('Flat Top PAM');
xlabel('Time (s)');
ylabel('Amplitude');
    
% Plot the Demodulation of FLAT TOP PAM signal
    subplot(4,1,4);
    plot(t, demodulated_signal); % need equalizer 
    title('Demodulation of PAM');
    xlabel('Time (s)');
    ylabel('Amplitude');
    ylim([-1.5 1.5]);
 


 %%%%%%%%%%%%% PWM %%%%%%%%%%%%%%
%PWM Modulation

 A= 2;
 t2 = 0:1/fs:2;             % sampling period
u = sin(2*pi*fm*t2);        % message signal

 pwm_signal = PWM(t2,A,u);




% PWM Demodulation 

TS = 0.001;         % Sampling time
T = 1;              % PWM period
duty_cycle = 0.3;   % PWM duty cycle

A2 = 2;
t2 = 0:1/fs:2;          % sampling period
u = sin(2*pi*fm*t2);     % message signal


% Example values for fc and Ts, adjust as needed
fc2 = 10;
Ts2 = 1/fs;

%[demodulated_pwm] = pwm_demod(t2, pwm_signal);
%[demodulated_signal2,time_vector]  = pwm_demod(pwm_signal,TS);
demodulated_pwm = pwm_demod(t2,pwm_signal);

figure;
% Plot the Message signal
subplot(3,1,1);
plot(t2,u);
ylim([-1.2 1.2]);
title('Message');
xlabel('Time (s)');
ylabel('Amplitude');
% Plot the Carrier signal
% subplot(4,1,2);
% plot(t2,s);
% ylim([-0.2 1.2]);
% title('Carrier');
% xlabel('Time (s)');
% ylabel('Amplitude');
 % Plot the PAM signal
subplot(3,1,2);
plot(t2,pwm_signal);
ylim([-1 3]);
title('PWM');
xlabel('Time (s)');
ylabel('Amplitude');

subplot(3,1,3);
plot(demodulated_pwm);
ylim([-1 3]);
title('PWM Demodulation');
xlabel('Time (s)');
ylabel('Amplitude');


                                        %%% PPM %%%

pwm_signal2 = [zeros(1, 20), ones(1, 20), zeros(1, 20), ones(1, 20)]; % Short PWM signal
ppm_period = 40; % Replace this with your desired PPM period
ppm_pulse_position = -0.000; % Replace this with the desired PPM pulse position
sampling_rate = 4; % Replace this with your sampling rate
ppm_signal = PPM(pwm_signal, ppm_period, ppm_pulse_position, sampling_rate);



                                      % PPM Demodulation %

reconstructed_message = ppm_demod(ppm_signal, ppm_period, sampling_rate,x);



