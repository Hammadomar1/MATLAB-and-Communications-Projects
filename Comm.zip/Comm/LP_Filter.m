
function [demodulated_signal, t] = LP_Filter(PAM_signal, fs, cutoff_frequency)
   
    % Adjust the filter length
    filter_length = 400; %varying the sharpness of the LPF (filter Length)  
    LPF = fir1(filter_length, cutoff_frequency / (100*(fs / 2)));

    %  convolution
    demodulated_signal = 2.*conv(PAM_signal, LPF, 'same');

    t = (0:(length(demodulated_signal) - 1))* 100 / fs;

    end


