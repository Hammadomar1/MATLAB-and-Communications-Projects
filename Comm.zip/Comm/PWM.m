


function pwm_signal = PWM(t,A,m)
fc= 10;
c2 = A.*sawtooth(2*pi*fc*t); % sawtooth carrier to produce the pwm signal
for i = 1: length(c2)
if m(i) >= c2(i)
    pwm_signal(i) = A; % if the message signal is greater than sawtooth -> generates a pulse of 1 and stays till it's not
else
    pwm_signal(i) = 0;
end
end
end
