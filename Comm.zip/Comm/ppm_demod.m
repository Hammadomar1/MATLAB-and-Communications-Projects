function reconstructed_message = ppm_demod(ppm_signal, ppm_period, sampling_rate, message_signal)
    ppm_threshold = 0.5; 

    % Detect rising edges of PPM signal
    rising_edges = find(diff(ppm_signal > ppm_threshold) > 0);
    time_vector = (0:length(ppm_signal) - 1) / sampling_rate;
    reconstructed_message = zeros(size(time_vector));

    for i = 1:length(rising_edges)
        pulse_position = round(rising_edges(i));
        pulse_start = max(1, pulse_position - round(ppm_period / 2 * sampling_rate));
        pulse_end = min(length(ppm_signal), pulse_position + round(ppm_period / 2 * sampling_rate));
        pulse_start = max(pulse_start, 1);
        pulse_end = min(pulse_end, length(ppm_signal));

        reconstructed_message(pulse_start:pulse_end) = ...
            reconstructed_message(pulse_start:pulse_end) + message_signal(pulse_start:pulse_end);
    end

    figure;
    subplot(2, 1, 1);
    plot(time_vector, ppm_signal);
    title('PPM Signal');
    xlabel('Time');
    ylabel('Amplitude');

    subplot(2, 1, 2);
    plot(time_vector, (1/20)*reconstructed_message);
    title('Reconstructed Message Signal');
    xlabel('Time');
    ylabel('Amplitude');
end