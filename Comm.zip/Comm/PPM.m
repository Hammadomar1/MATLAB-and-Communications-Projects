function ppm_signal = PPM(pwm_signal, ppm_period, ppm_pulse_position, sampling_rate)

    pwm_high_low = 0.5; % when PWM  high or low.

    rising_edges = find(diff(pwm_signal > pwm_high_low) < 0);

    ppm_signal = zeros(size(pwm_signal));
    time_vector = (0:length(pwm_signal) - 1) / sampling_rate;

    for i = 1:length(rising_edges)
        pulse_position = round(ppm_pulse_position * ppm_period);
        start_index = rising_edges(i) - pulse_position + 1;
        end_index = min(start_index + ppm_period - 1, length(pwm_signal));
        
        start_index = max(start_index, 1);
        end_index = min(end_index, length(pwm_signal));

        ppm_signal(start_index:end_index) = 1;
    end

    % Plot the signals
    figure;
    subplot(2, 1, 1);
    plot(time_vector, pwm_signal);
    title('PWM Signal');
    xlabel('Time');
    ylabel('Amplitude');
    ylim([-0 1.5]);

    subplot(2, 1, 2);
    plot(time_vector, ppm_signal);
    title('PPM Signal');
    xlabel('Time');
    ylabel('Amplitude');
    ylim([-0 1.5]);
end