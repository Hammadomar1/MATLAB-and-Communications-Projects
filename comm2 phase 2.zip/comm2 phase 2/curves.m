% Define simulation parameters
EbN0_dB = -2:1:10; % Range of Eb/N0 values
numSymbols = 1e6; % Number of symbols to simulate

% Preallocate BER arrays
BER_QPSK_simulated = zeros(size(EbN0_dB));
BER_16QAM_simulated = zeros(size(EbN0_dB));

% Loop over all Eb/N0 points for QPSK and 16-QAM
for n = 1:length(EbN0_dB)
    % QPSK Simulation
    dataIn_QPSK = randi([0 1], numSymbols * 2, 1); % Generate data
    txSymbols_QPSK = pskmod(dataIn_QPSK, 4, pi/4, 'gray', 'InputType', 'bit');
    rxSymbols_QPSK = awgn(txSymbols_QPSK, EbN0_dB(n) + 10*log10(2), 'measured');
    dataOut_QPSK = pskdemod(rxSymbols_QPSK, 4, pi/4, 'gray', 'OutputType', 'bit');
    BER_QPSK_simulated(n) = sum(dataIn_QPSK ~= dataOut_QPSK) / length(dataIn_QPSK);
    
    % 16-QAM Simulation
    dataIn_16QAM = randi([0 1], numSymbols * 4, 1); % Generate data
    txSymbols_16QAM = qammod(dataIn_16QAM, 16, 'InputType', 'bit', 'UnitAveragePower', true);
    rxSymbols_16QAM = awgn(txSymbols_16QAM, EbN0_dB(n) + 10*log10(4), 'measured');
    dataOut_16QAM = qamdemod(rxSymbols_16QAM, 16, 'OutputType', 'bit', 'UnitAveragePower', true);
    BER_16QAM_simulated(n) = sum(dataIn_16QAM ~= dataOut_16QAM) / length(dataIn_16QAM);
end

% Theoretical BER Calculation
BER_QPSK_theoretical = erfc(sqrt(10.^(EbN0_dB/10))) / 2;
BER_16QAM_theoretical = (3/2) * erfc(sqrt((4/10) * 10.^(EbN0_dB/10)));

% Plot the results
figure;
semilogy(EbN0_dB, BER_QPSK_simulated, 'b-o', EbN0_dB, BER_16QAM_simulated, 'r-s');
hold on;
semilogy(EbN0_dB, BER_QPSK_theoretical, 'b--', EbN0_dB, BER_16QAM_theoretical, 'r--');
grid on;
legend('QPSK Simulated', '16-QAM Simulated', 'QPSK Theoretical', '16-QAM Theoretical');
ylabel('Bit Error Rate (BER)');
title('BER vs. E_b/N_0 for 16-QAM over AWGN Channel');