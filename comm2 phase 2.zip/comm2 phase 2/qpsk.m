% Define the range of Eb/No values (in dB)
eb_no_dB = -2:1:10;  % From -2 dB to 10 dB
eb_no_lin = 10.^(eb_no_dB / 10);  % Convert dB to linear scale

% Number of bits for the simulation (higher the better for accuracy but slower simulation)
num_bits = 100000;

% Initialize BER arrays
ber_simulated = zeros(1, length(eb_no_dB));

% Theoretical BER calculation using QPSK in AWGN
ber_theoretical = 0.5 * erfc(sqrt(eb_no_lin));

% Simulation
for i = 1:length(eb_no_lin)
    % Generate random bits
    bits = randi([0 1], 1, num_bits);

    % QPSK modulation (Gray coding: 00 -> -1-j, 01 -> -1+j, 10 -> 1-j, 11 -> 1+j)
    symbols = 2 * reshape(bits, 2, []) - 1;  % Convert bits to +1/-1 and reshape
    symbols = (symbols(1,:) + 1j * symbols(2,:)) / sqrt(2);  % Scale to unit power

    % Add AWGN noise
    noise_variance = 1 / (2 * eb_no_lin(i));  % Noise variance calculation
    noise = sqrt(noise_variance) * (randn(1, length(symbols)) + 1j * randn(1, length(symbols)));
    received_symbols = symbols + noise;

    % Demodulation (ML detection assuming Gray coding)
    detected_bits = zeros(1, num_bits);
    detected_bits(1:2:end) = real(received_symbols) > 0;  % Real part maps to even bits
    detected_bits(2:2:end) = imag(received_symbols) > 0;  % Imaginary part maps to odd bits

    % BER calculation
    ber_simulated(i) = mean(detected_bits ~= bits);
end

% Plotting
figure;
semilogy(eb_no_dB, ber_simulated, 'bo-'); hold on;
semilogy(eb_no_dB, ber_theoretical, 'r*-');
xlabel('E_b/N_0 (dB)');
ylabel('BER');
title('BER vs. E_b/N_0 for QPSK in AWGN');
legend('Simulated BER', 'Theoretical BER');
grid on;
