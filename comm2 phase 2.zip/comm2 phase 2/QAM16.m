% Generate a binary sequence of 1 million bitss
binary_sequence = randi([0 1], 1e6, 1);
seq_length = numel(binary_sequence);

% Modulating the binary sequence using 16-QAM
modulated_signal = qammod(binary_sequence, 16);

% array to store Bit Error Rates (BER)
simulated_BER = zeros(1, 13);

% Loop over different Signal-to-Noise Ratios (SNRs)
for SNR_val = -2:10
    % Adding AWGN noise 
    noisy_modulated_signal = awgn(modulated_signal, (SNR_val + 2) / 2);
    % Demodulate the received noisy signal
    demodulated_sequence = qamdemod(noisy_modulated_signal, 16);

    % Initialize error count
    count_errors = 0;
    % Count bit errors
    for k = 1:seq_length
        if binary_sequence(k) ~= demodulated_sequence(k)
            count_errors = count_errors + 1;
        end
    end
    % Calculate BER for current SNR
    simulated_BER(SNR_val + 3) = count_errors / seq_length;
end

% Define Eb/N0 range for plotting
EbNo_values = -2:1:10;
% Calculate theoretical BER for QPSK
theoretical_BER = berawgn(EbNo_values, 'qam', 16);

% Plotting the BER vs. Eb/N0
semilogy(EbNo_values, simulated_BER, EbNo_values, theoretical_BER);
ylabel('Bit Error Rate');
xlabel('Eb/N0 (dB)');
title('Bit Error Rate for 16-QAM');
legend('16-QAM Simulation', '16-QAM Closed form');
