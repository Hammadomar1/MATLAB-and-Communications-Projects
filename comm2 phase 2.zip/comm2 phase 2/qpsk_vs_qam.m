% Initialization of a binary data stream of 1 million bits
binary_stream = randi([0 1], 10^6, 1);
stream_length = numel(binary_stream);

% QPSK modulation of the binary data
modulated_QPSK = pskmod(binary_stream, 4);

% Array to hold simulated BER values for QPSK
simulated_BER_QPSK = zeros(1, 13);

% Iterating through SNR values for QPSK
for current_SNR = -2:10
    % Adding noise to the QPSK modulated signal
    noisy_QPSK = awgn(modulated_QPSK, current_SNR + 3.5);
    % Demodulating the noisy QPSK signal
    demodulated_QPSK = pskdemod(noisy_QPSK, 4);

    % Reset error count for each SNR value
    num_errors_QPSK = 0;

    % Counting errors in QPSK demodulation
    for index = 1:stream_length
        if binary_stream(index) ~= demodulated_QPSK(index)
            num_errors_QPSK = num_errors_QPSK + 1;
        end
    end

    % Calculating BER for current SNR in QPSK
    simulated_BER_QPSK(current_SNR + 3) = num_errors_QPSK / stream_length;
end

% QAM modulation of the same binary data
modulated_QAM = qammod(binary_stream, 16);

% Array to hold simulated BER values for 16-QAM
simulated_BER_QAM = zeros(1, 13);

% Iterating through SNR values for 16-QAM
for current_SNR = -2:10
    % Adding noise to the 16-QAM modulated signal
    noisy_QAM = awgn(modulated_QAM, (current_SNR + 2) / 2);
    % Demodulating the noisy 16-QAM signal
    demodulated_QAM = qamdemod(noisy_QAM, 16);

    % Reset error count for each SNR value
    num_errors_QAM = 0;

    % Counting errors in 16-QAM demodulation
    for index = 1:stream_length
        if binary_stream(index) ~= demodulated_QAM(index)
            num_errors_QAM = num_errors_QAM + 1;
        end
    end

    % Calculating BER for current SNR in 16-QAM
    simulated_BER_QAM(current_SNR + 3) = num_errors_QAM / stream_length;
end

% Range of Eb/N0 values for plotting
EbNo_range = -2:1:10;

% Theoretical BER for QPSK and 16-QAM
theoretical_BER_QPSK = berawgn(EbNo_range, 'psk', 2, 'nondiff');
theoretical_BER_QAM = berawgn(EbNo_range, 'qam', 16);

% Plotting BER vs. Eb/N0 for QPSK and 16-QAM
semilogy(EbNo_range, simulated_BER_QPSK, EbNo_range, theoretical_BER_QPSK, ...
         EbNo_range, simulated_BER_QAM, EbNo_range, theoretical_BER_QAM);
ylabel('Bit Error Rate');
xlabel('Eb/N0 (dB)');
title('Bit Error Rate Comparison: QPSK vs. 16-QAM');
legend('Simulated QPSK', 'Closed form QPSK', 'Simulated 16-QAM', 'Closed form 16-QAM');
