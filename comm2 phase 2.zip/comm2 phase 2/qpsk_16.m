% Number of symbols to transmit
numSymbols = 1000;

% Define 16-QAM constellation
M = 16; % 16-QAM
k = log2(M); % Bits per symbol
constellation = qammod(0:M-1, M, 'UnitAveragePower', true);

% Eb/N0 range in dB
EbN0_dB = -2:1:10; % From -2 dB to 10 dB
EbN0_lin = 10.^(EbN0_dB / 10); % Linear scale

% Pre-allocate BER vectors
BER_simulated = zeros(size(EbN0_dB));
BER_theoretical = zeros(size(EbN0_dB));

% Loop over all Eb/N0 points
for n = 1:length(EbN0_dB)
    % Calculate noise variance for current Eb/N0
    N0 = 1 / (EbN0_lin(n) * k);

    % Generate random bit stream
    dataIn = randi([0 1], numSymbols * k, 1);

    % Modulate the bits
    txSymbols = qammod(dataIn, M, 'InputType', 'bit', 'UnitAveragePower', true);

    % Add AWGN
    noise = sqrt(N0/2) * (randn(size(txSymbols)) + 1i * randn(size(txSymbols)));
    rxSymbols = txSymbols + noise;

    % Demodulate the received symbols
    dataOut = qamdemod(rxSymbols, M, 'OutputType', 'bit', 'UnitAveragePower', true);

    % Calculate the number of bit errors
    nErrors = sum(dataOut ~= dataIn);

    % Calculate and store the BER
    BER_simulated(n) = nErrors / (numSymbols * k);

    % Theoretical BER calculation
    BER_theoretical(n) = (4/k) * (1 - 1/sqrt(M)) * qfunc(sqrt((3*k*EbN0_lin(n))/(M-1)));
end

% Plot the results
figure;
semilogy(EbN0_dB, BER_simulated, 'bo-', 'LineWidth', 1.5);
hold on;
semilogy(EbN0_dB, BER_theoretical, 'r--', 'LineWidth', 1.5);
grid on;
legend('Simulated BER', 'Theoretical BER');
xlabel('E_b/N_0 (dB)');
ylabel('Bit Error Rate (BER)');
title('BER vs. E_b/N_0 for 16-QAM over AWGN Channel');
