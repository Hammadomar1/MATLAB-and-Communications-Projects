% Generate a binary sequence of 1 million bits
data_bits = randi([0, 1], 1e6, 1);
num_bits = numel(data_bits);

% Modulating the binary sequence using QPSK scheme
QPSK_modulated = pskmod(data_bits, 4);

% array to store Bit Error Rates (BER)
BER_simulation = zeros(1, 13);

% Loop over different Signal-to-Noise Ratios (SNRs)
for SNR_value = -2:10
    % Adding AWGN noise
    noisy_signal = awgn(QPSK_modulated, SNR_value + 3.5);
    % Demodulate the received noisy signal
    demodulated_data = pskdemod(noisy_signal, 4);

    % Initialize error count
    Errors = 0;
    % Count bit errors
    for j = 1:num_bits
        if data_bits(j) ~= demodulated_data(j)
            Errors = Errors + 1;
        end
    end
    % Calculate BER for current SNR
    BER_simulation(SNR_value + 3) = Errors / num_bits;
end

% Define Eb/N0 range for plotting

EbNo_range = -2:10;
% Calculate theoretical BER for QPSK
BER_theoretical = berawgn(EbNo_range, 'psk', 2, 'nondiff');

% Plotting the BER vs. Eb/N0
semilogy(EbNo_range, BER_simulation, EbNo_range, BER_theoretical);
ylabel('Bit Error Rate');
xlabel('Eb/N0 (dB)');
title('BER Comparison for QPSK');
legend('Simulated BER', 'Theoretical BER');
