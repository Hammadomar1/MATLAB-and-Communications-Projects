% Range required of Eb/No 
Eb_No = -2:1:10;

%convert Eb/No to SNR
SNR = Eb_No + 10*log10(1/2);

%array of random bits
data_bits = randi([0,1],1,10^6);

% BPSK Modulation
signal_transmitted = 2*data_bits - 1;

% Loop through each SNR to simulate transmission over AWGN channel
BER_simulated = zeros(size(Eb_No));
for q = 1:length(SNR)
    % Adding Gaussian noise to signal
    signal_received = awgn(signal_transmitted, SNR(q), 'measured');
    
    % Demodulating the signal using BPSK
    bits_receiver = signal_received > 0;
    
    % bit error rate calculation
    BER_simulated(q) = sum(xor(data_bits, bits_receiver))/length(data_bits);
end

% theoretical BER using BPSK over AWGN 
BER_theoretical = (1/2)*erfc(sqrt(10.^(SNR/10)));

% Plot of all BER 
semilogy(Eb_No, BER_simulated, 'bo-', Eb_No, BER_theoretical, 'r.-');
grid on;
xlabel('E_b/N_0 (dB)');
ylabel('Bit Error Rate (BER)');
legend('Simulated', 'Theoretical');
title('BER vs E_b/N_0 for BPSK over AWGN Channel');
