% Assuming EbN0_dB, BER_simulated, BER_simulated_coherent, BER_simulated_non_coherent,
% BER_theoretical, BER_theoretical_coherent, and BER_theoretical_non_coherent are defined

figure; hold on;

% Plot BPSK
semilogy(EbN0_dB, BER_simulated, 'b-o', 'LineWidth', 2, 'MarkerSize', 8);
semilogy(EbN0_dB, BER_theoretical, 'b--', 'LineWidth', 2);

% Plot BFSK Coherent
semilogy(EbN0_dB, BER_simulated_coherent, 'g-s', 'LineWidth', 2, 'MarkerSize', 8);
semilogy(EbN0_dB, BER_theoretical_coherent, 'g--', 'LineWidth', 2);

% Plot BFSK Non-Coherent
semilogy(EbN0_dB, BER_simulated_non_coherent, 'r-^', 'LineWidth', 2, 'MarkerSize', 8);
semilogy(EbN0_dB, BER_theoretical_non_coherent, 'r--', 'LineWidth', 2);

grid on;
xlabel('E_b/N_0 (dB)', 'FontSize', 12);
ylabel('Bit Error Rate (BER)', 'FontSize', 12);
title('BER vs E_b/N_0 for BPSK and BFSK over AWGN Channel', 'FontSize', 14);
legend('BPSK Simulated', 'BPSK Theoretical', 'BFSK Coherent Simulated', 'BFSK Coherent Theoretical', 'BFSK Non-Coherent Simulated', 'BFSK Non-Coherent Theoretical', 'Location', 'southwest');
set(gca, 'FontSize', 12);
hold off;
