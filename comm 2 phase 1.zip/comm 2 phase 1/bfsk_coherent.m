% Parameters
EbN0_dB = -2:1:10; % Eb/N0 range from -2 dB to 10 dB
EbN0 = 10.^(EbN0_dB/10);

% Pre-allocate variables for speed
BER_simulated_coherent = zeros(size(EbN0));

for i = 1:length(EbN0)
    % Generate random bits
    data = randi([0, 1], 1, 10^6);
    
    % BFSK modulation
    s1 = ones(size(data)); % Frequency f1 for bit 1
    s2 = -ones(size(data)); % Frequency f2 for bit 0
    modulated = s1.*(data==1) + s2.*(data==0);
    
    % Add AWGN noise
    noise = sqrt(1/(2*EbN0(i))) * randn(1, 10^6);
    received = modulated + noise;
    
    % BFSK Coherent demodulation
    demodulated = received > 0;
    
    % Calculate BER
    BER_simulated_coherent(i) = sum(data ~= demodulated)/N;
end

% Theoretical BER for BFSK Coherent
BER_theoretical_coherent = 0.5 * exp(-EbN0);

% Plot
figure;
semilogy(EbN0_dB, BER_simulated_coherent, 'go-', 'LineWidth', 2);
hold on;
semilogy(EbN0_dB, BER_theoretical_coherent, 'r--', 'LineWidth', 2);
grid on;
xlabel('E_b/N_0 (dB)');
ylabel('Bit Error Rate (BER)');
legend('Simulated Coherent', 'Theoretical Coherent');
title('BER vs E_b/N_0 for BFSK (Coherent Detector) over AWGN Channel');
