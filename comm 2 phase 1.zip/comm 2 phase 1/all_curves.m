% Parameters
EbN0_dB = -2:1:10; % Eb/N0 range from -2 dB to 10 dB
EbN0 = 10.^(EbN0_dB/10);
N = 10^6; % Number of bits to simulate

% BPSK Simulation
data_bits = randi([0,1], 1, N);
signal_transmitted = 2*data_bits - 1;
SNR = EbN0_dB + 10*log10(1/2); % Convert Eb/N0 to SNR for BPSK
BER_simulated_BPSK = zeros(size(EbN0));

for q = 1:length(SNR)
    signal_received = awgn(signal_transmitted, SNR(q), 'measured');
    bits_received = signal_received > 0;
    BER_simulated_BPSK(q) = sum(data_bits ~= bits_received)/N;
end

BER_theoretical_BPSK = 0.5*erfc(sqrt(10.^(SNR/10)));

% BFSK Coherent Simulation
BER_simulated_coherent = zeros(size(EbN0));

for i = 1:length(EbN0)
    data = randi([0, 1], 1, N);
    s1 = ones(size(data)); % Frequency f1 for bit 1
    s2 = -ones(size(data)); % Frequency f2 for bit 0
    modulated = s1.*(data==1) + s2.*(data==0);
    noise = sqrt(1/(2*EbN0(i))) * randn(1, N);
    received = modulated + noise;
    demodulated = received > 0;
    BER_simulated_coherent(i) = sum(data ~= demodulated)/N;
end

BER_theoretical_coherent = 0.5 * exp(-EbN0);

% BFSK Non-Coherent Simulation
BER_simulated_non_coherent = zeros(size(EbN0));

for i = 1:length(EbN0)
    data = randi([0, 1], 1, N);
    s1 = ones(size(data)); % Frequency f1 for bit 1
    s2 = -ones(size(data)); % Frequency f2 for bit 0
    modulated = s1.*(data==1) + s2.*(data==0);
    noise = sqrt(1/EbN0(i)) * randn(1, N);
    received = modulated + noise;
    demodulated = received > 0;
    BER_simulated_non_coherent(i) = sum(data ~= demodulated)/N;
end

BER_theoretical_non_coherent = 0.5 * exp(-EbN0/2);

% Combined Plot
figure;
semilogy(EbN0_dB, BER_simulated_BPSK, 'b-o', 'MarkerSize', 6);
hold on;
semilogy(EbN0_dB, BER_theoretical_BPSK, 'b--');
semilogy(EbN0_dB, BER_simulated_coherent, 'g-s', 'MarkerSize', 6);
semilogy(EbN0_dB, BER_theoretical_coherent, 'g--');
semilogy(EbN0_dB, BER_simulated_non_coherent, 'r-^', 'MarkerSize', 6);
semilogy(EbN0_dB, BER_theoretical_non_coherent, 'r--');

xlabel('E_b/N_0 (dB)');
ylabel('Bit Error Rate (BER)');
legend('BPSK Simulated', 'BPSK Theoretical', 'BFSK Coherent Simulated', 'BFSK Coherent Theoretical', 'BFSK Non-Coherent Simulated', 'BFSK Non-Coherent Theoretical');
title('Combined BER vs E_b/N_0 for BPSK and BFSK over AWGN Channel');
grid on;
hold off;
