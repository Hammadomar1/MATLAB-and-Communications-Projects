function testVoiceCodecWithoutNoise(audio, fs_original)
    % Set testing parameters
    sampling_frequencies = [32000, 16000, 4000];
    num_levels_list = [16, 64, 256];

    for target_fs = sampling_frequencies
        for num_levels_test = num_levels_list
            % Resample the audio to the target sampling frequency
            audio_resampled = resample(audio, target_fs, fs_original);
            
            % Test the Voice Codec functions
            [time_vector, sampled_signal] = sampler(audio_resampled, target_fs);
            peak_quantization_level = max(abs(sampled_signal));
            quantizer_type = 'mid-rise';
            [~, ~, bitstream] = quantizer(time_vector, sampled_signal, quantizer_type, num_levels_test, peak_quantization_level);

            encoding_types = {'manchester', 'ami'};
            for encoding_type = encoding_types
                pulse_amplitude = 1;
                bit_duration = 0.01;
                encoded_signal = encoder(bitstream, encoding_type{1}, pulse_amplitude, bit_duration);
                displayResults(target_fs, num_levels_test, encoding_type{1}, bitstream, encoded_signal);
            end
        end
    end
end