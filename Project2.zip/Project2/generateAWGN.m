% Additional function: Generate AWGN
function noise = generateAWGN(signal, N0)
    noise_power = N0 * var(signal);
    noise = sqrt(noise_power) * randn(size(signal));
end