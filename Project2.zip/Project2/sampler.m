% 1) Sampler Function
function [time_vector, sampled_signal] = sampler(input_signal, sampling_frequency)
    time_vector = 0:1/sampling_frequency:(length(input_signal)-1)/sampling_frequency;
    sampled_signal = input_signal;
end