% Additional function: Display Results
function displayResults(fs, num_levels, encoding_type, bitstream, encoded_signal)
    % Display or process the results as needed
    fprintf('Results: fs=%d, num_levels=%d, encoding_type=%s\n', fs, num_levels, encoding_type);
    % Display the first 20 bits of the bitstream
    fprintf('First 20 bits of bitstream: %s\n', bitstream(1:20));
    
    % Save the encoded signal as an audio file
    saveAudioFile(encoded_signal, fs, ['encoded_audio_fs' num2str(fs) '_L' num2str(num_levels) '_' encoding_type '.wav']);
    
    % Decode the signal
    decoded_signal = decoder(encoded_signal, 'mid-rise', num_levels, max(abs(sampled_signal)));
    
    % Save the decoded audio file
    saveAudioFile(decoded_signal, fs, ['decoded_audio_fs' num2str(fs) '_L' num2str(num_levels) '_' encoding_type '.wav']);
end