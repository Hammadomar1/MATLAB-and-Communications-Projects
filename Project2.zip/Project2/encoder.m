% 3) Encoder Function
function encoded_signal = encoder(bitstream, encoding_type, pulse_amplitude, bit_duration)
    if strcmp(encoding_type, 'manchester')
        encoded_signal = [];
        for bit = bitstream
            if bit == '1'
                encoded_signal = [encoded_signal ones(1, bit_duration / 2) * pulse_amplitude -ones(1, bit_duration / 2) * pulse_amplitude];
            else
                encoded_signal = [encoded_signal -ones(1, bit_duration / 2) * pulse_amplitude ones(1, bit_duration / 2) * pulse_amplitude];
            end
        end
    elseif strcmp(encoding_type, 'ami')
        encoded_signal = pulse_amplitude * (bitstream == '1');
    else
        error('Invalid encoding type');
    end
end

