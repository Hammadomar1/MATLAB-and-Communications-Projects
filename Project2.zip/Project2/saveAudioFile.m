% Additional function: Save Audio File
function saveAudioFile(decoded_signal, fs, file_name)
    audiowrite(file_name, decoded_signal, fs);
end