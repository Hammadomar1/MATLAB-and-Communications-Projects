% 2) Quantizer Function
function [mean_square_error, quantized_signal, bitstream] = quantizer(time_vector, input_signal, quantizer_type, num_levels, peak_quantization_level)
    % Quantize the input signal
    if strcmp(quantizer_type, 'mid-rise')
        quantized_signal = round(input_signal / peak_quantization_level * (num_levels - 1)) * peak_quantization_level / (num_levels - 1);
    elseif strcmp(quantizer_type, 'mid-tread')
        quantized_signal = round((input_signal + peak_quantization_level / 2) / peak_quantization_level * (num_levels - 1)) * peak_quantization_level / (num_levels - 1);
    else
        error('Invalid quantizer type');
    end

    % Calculate mean square quantization error
    mean_square_error = mean((input_signal - quantized_signal).^2);

    % Display the input and quantized signals
    figure;
    plot(time_vector, input_signal, 'DisplayName', 'Input Signal');
    hold on;
    stairs(time_vector, quantized_signal, 'DisplayName', 'Quantized Signal');
    legend;
    xlabel('Time (s)');
    ylabel('Amplitude');
    title('Input and Quantized Signals');

    
    % Convert quantized signal to bitstream
    bitstream = char(quantized_signal > 0) + '0';
end