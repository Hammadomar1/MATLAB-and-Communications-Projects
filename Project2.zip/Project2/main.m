% Test Case 1
file_path = 'Dr.Samy.wav';  %audio file
[audio, fs] = readAudioFile(file_path);
testVoiceCodecWithoutNoise(audio, fs);



% 
% % Test Case 2
% fs_test = 32000;
% num_levels_test = 256;
% noise_levels = [0.25, 0.5, 1, 2.5];
% testVoiceCodecWithNoise(fs_test, num_levels_test, noise_levels);

