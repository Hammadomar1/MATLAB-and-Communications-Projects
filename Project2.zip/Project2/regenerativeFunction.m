% Additional function: Regenerative Function
function regenerated_pulses = regenerativeFunction(noisy_pulses, threshold)
    regenerated_pulses = sign(noisy_pulses - threshold);
end