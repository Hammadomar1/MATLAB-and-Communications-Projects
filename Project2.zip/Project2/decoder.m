% 4) Decoder Function
function decoded_signal = decoder(encoded_signal, quantizer_type, num_levels, peak_quantization_level)
    % Decode the bitstream
    decoded_bits = char(encoded_signal > 0 + '0');

    % Convert bits back to quantized samples
    decoded_signal = bin2dec(decoded_bits) * peak_quantization_level / (num_levels - 1);

    % Display the decoded quantized samples
    figure;
    stem(decoded_signal);
    xlabel('Sample Index');
    ylabel('Amplitude');
    title('Decoded Quantized Samples');
end