function [audio, fs] = readAudioFile(file_path)
    [audio, fs] = audioread(file_path);
end