function arcAnalytical = arcLength_Analytically(Coeff, x)

f1 = @(X) sqrt(1 + Coeff(1,2)^2) * X;
I1 = f1(x(2)) - f1(x(1)); %1st spline integration
I2 = 0; 
j = 2;

%here i => ai, i+1 => bi, i+2 => ci
for i = 4:3:length(Coeff)
    f2 = @(X) (1/(4*Coeff(i))) * (sqrt((2 * Coeff(i)*X + Coeff(i+1))^2 + 1) * (2*Coeff(i)*X + Coeff(i + 1)) + asinh(2 * Coeff(i) * X + Coeff(i+1)));
    I2 = I2 + (f2(x(j + 1)) - f2(x(j)));
    j = j + 1;
end

arcAnalytical = I1 + I2;

 fprintf('The Analytical integration result is: %f \n',arcAnalytical);
end
