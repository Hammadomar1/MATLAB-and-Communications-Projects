function Itotal = arclength_numerical(x,Y)
%dataset= dataset';
% x = dataset(:, 1);
% Y=dataset(:, 2);
n=length(x);
h=(max(x)-min(x))/(n-1);

%Forward method for derivitive of first point
            point=1; %counter for the given data
            dydx=(-Y(3)+4*Y(2)-3*Y(1))/(2*h); %eq. of f'(x) using o(h^2)
            derv(1,point)=dydx; %Storing f'(x) in derivtive matrix

%Backward method for derivtive of last point            
            point=n;
            dydx=(3*Y(n)-4*Y(n-1)+Y(n-2))/(2*h);
            derv(1,point)=dydx;

%Centered method for derivtives of points inbetween           
            point=2;
            for i=2:n-1           
                dydx=(Y(i+1)-Y(i-1))/(2*h);
                derv(1,point)=dydx;
                point=point+1; %incrementation 
            end
            root=[]; %defining value inside integral
            for i=1:length(derv)
                root(i)=sqrt(1+(derv(i)^2)); %eq. inside integral
            end

        f = root;
        
        Itotal = trapezoidal(x(1:2), f(1:2));
            if (mod(n-2, 2) == 0)
            Itotal = Itotal + simpson13(x(2:end), f(2:end));
            else
            Itotal = Itotal + simpson13(x(2:n-1), f(2:n-1)) + trapezoidal(x(n-1:n), f(n-1:n));
            end

 fprintf('The Total integration is: %f \n',Itotal); 
 
end