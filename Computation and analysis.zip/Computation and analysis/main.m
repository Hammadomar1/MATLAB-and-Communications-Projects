% This Code is developed by Hammad Omar, Hassan Mohamed Hassan, 
% Sara Abdel Haleem, and Nour Zain on the 10th of December,2022.
clear
clc
close all

% This code aims to calculate Spline Equations and Curve/Arc Length for
% the top profile of the duck.

%P.S: If you tried other datasets, please check line 13 & 14 in main file
%to make sure if the data is set in columns or rows.

dataset= readmatrix("Top_profile_dataset.xlsx");
X= dataset(:, 1);
Y=dataset(:, 2);
x = X(1):min(diff(X)):X(end);
y = interp1(X,Y,x);
Coeff=splines(x,y);
spline_plotting(Coeff, x,y);
arclengthNum=arclength_numerical(x,y); 
arcAnalytical = arcLength_Analytically(Coeff,x);