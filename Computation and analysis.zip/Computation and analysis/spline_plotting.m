function p=spline_plotting(coeff,x,y)
n = length(x)-1;
scatter(x, y, 14, "b", "o", "filled");
j = 1;
hold on
for i = 1:n
    spline = @(x) coeff(j) * x.^2 + coeff(j+1) * x + coeff(j+2);
    fplot(spline, [x(i), x(i + 1)], "red")
    j = j + 3;
end

grid on;
title("Data points and superimposed Quadratic Splines")
xlabel("x")
ylabel("y")
legend("points", "splines")
hold off

p = 0;
end