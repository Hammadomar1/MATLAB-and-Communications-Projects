function I = simpson13(X,Y)
%SIM13 Summary of this function goes here
%   Detailed explanation goes here
n= length(X);
a=X(1);
b=X(end);
h=(b-a)/(n-1);
Oddsum=0;
Evensum=0;
for i= 2:2:n-1 %n-1 (number of segments) is an even number to make sure that simpson 1/3 is operating correctly
       Oddsum=Oddsum+Y(i); %sum of odd terms
end

for i=3:2:n-2
       Evensum=Evensum+Y(i); %sum of even terms  
end

I= h*(Y(1) + Y(end) + 4.*Oddsum + 2*Evensum)/3; % 1/3 simpson's formula

fprintf('\nThe Integration result by Simpson 1/3 method is: %f \n',I); 

end


