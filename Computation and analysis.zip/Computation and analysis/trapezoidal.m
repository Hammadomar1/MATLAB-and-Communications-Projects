function I = trapezoidal(X,Y)
%TRAP Calculate integral using trapozoidal method
%   Detailed explanation goes here
n=length(X)-1;
a=X(1);
b=X(end);
h=(b-a)/n;
sum=0;

for idx= 2:length(X)-1
    sum= sum + Y(a+idx*h);
end

I = h/2.*(Y(1)+ Y(end)+ 2.*sum);

fprintf('The Integration result by trapezoidal method is: %f',I);