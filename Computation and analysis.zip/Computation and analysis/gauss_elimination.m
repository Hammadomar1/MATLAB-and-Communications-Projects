function x = gauss_elimination(A, b)
    
    % Check if A is square
    if(size(A, 1) ~= size(A, 2))    
        error("Matrix A is not square.. Aborting!");
    end
    
    det = 1;
    n = length(b);  % n of unknowns and eqs

    % I. Elimination Phase

    for k = 1:n-1
        
        for i=k+1:n             %% Partial pivoting
            p = k;
            big = abs(A(k, k));
            for ii = k + 1: n           %%%
                dummy = abs(A(ii, k));  % 
                if dummy > big          % Check for pivot element
                    big = dummy;        %
                    p = ii;             %%%
                end 
            end

            if(p ~= k)         % If pivot does ~= index, switch rows. 
                for jj = k:n
                    dummy = A(p, jj);
                    A(p, jj) = A(k, jj);
                    A(k, jj) = dummy;
                end
                dummy = b(p);  % Switch constants matrix elements likewise
                b(p) = b(k);
                b(k) = dummy;
            end

            factor = A(i, k) / A(k, k);       % Use of pivot for elimination

            A(i, k+1:n) = A(i, k+1:n) - factor*A(k, k+1:n);   % Elimination step

            b(i) = b(i) - factor*b(k);      % Apply same operation to the constants matrix
        end
    end

    %%% Check the determinant

    for i = 1:n
        det = det * A(i, i);
    end

        % Check if A is singular
     if det == 0
         error("System is singular. Infinite solutions... Aborting!")
     end
     
    % II. Backsub. Phase

    x(n) = b(n) / A(n, n);

    for i = n-1:-1:1
        sum = b(i);     % Intialise
        
        for j = i+1:n
            sum = sum - A(i, j)*x(j);   %%%
        end                             %
                                        % Solving eqs to get unknowns from
                                        % the bottom up
        x(i) = sum / A(i, i);           %
    end                                 %%%

end

